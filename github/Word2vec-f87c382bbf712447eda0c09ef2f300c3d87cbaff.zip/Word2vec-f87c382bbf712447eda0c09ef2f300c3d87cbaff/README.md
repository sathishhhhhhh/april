# Word2vec
Deep learning  for sentiment analysis - different Python implementations that use the word2vec model
